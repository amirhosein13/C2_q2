# تنظیمات پنل ادمین CMS 1.5.1 برای `conveyor`

برچسب‌ها همان متن فرم‌های پنل در CMS 1.5.1 است. ترتیب قدم‌ها مهم است: **تست‌ها قبل از Score Parameters**،
چون CMS پارامترهای GroupMin را هنگام Update با تست‌های موجود چک می‌کند و اگر تستی پیدا نکند خطای
«No testcase matches against the regexp» می‌دهد.

## ۱. ساخت سوال
Tasks → ساخت سوال → name = `conveyor`.
(CMS خودش یک dataset به نام `Default` با Batch/alone/diff و Score type = Sum می‌سازد؛ پایین درستش می‌کنیم.)

## ۲. Task configuration (بالای صفحه)
| فیلد پنل | مقدار |
|---|---|
| Name | `conveyor` |
| Title | `تسمه‌نقاله` |
| Statements → [add] | Language code: `fa`، فایل `statement-fa.pdf`، Upload؛ بعد تیک **Primary?** کنار `fa` |
| Attachments → [add] | `attachments/conveyor.zip` |
| Submission format | `conveyor.%l` |
| Feedback level | `Full` (یا `Restricted` اگر جزئیات تست‌ها نباید دیده شود) |
| Token mode | `Disabled` |
| Maximum number of submissions | `50` (پیشنهادی؛ خالی = نامحدود) |
| Maximum number of user tests | خالی |
| Minimum interval between submissions | `60` (ثانیه، پیشنهادی) |
| Minimum interval between user tests | خالی |
| Score decimal places | `2` |
| Score mode | **Use the sum over each subtask of the best result for that subtask across all submissions (IOI 2017-)** |

## ۳. Dataset «Default» (پایین صفحه)
| فیلد پنل | مقدار |
|---|---|
| Time limit | `1.0` second(s) |
| Memory limit | `256` MiB |
| Task type | `Batch` |
| Compilation | `Submissions are compiled with a grader` |
| I/O (blank for stdin/stdout) → Input file / Output file | هر دو **خالی** |
| Output evaluation | `Outputs are compared by a comparator` |
| Managers → [add] (یکی‌یکی) | `checker`, `conveyor.h`, `grader.cpp` (اسم فایل‌ها نباید عوض شود) |
| Score Type | `GroupMin` (در این مرحله هنوز Score Parameters را عوض نکنید) |

دکمه‌ی **Update** پایین صفحه.

## ۴. تست‌ها
Dataset → **Add multiple testcases**، برای هر فایل:
   - `testcases-part1.zip` (0.25 MB)
- Input file names template: `*.in` (پیش‌فرض پنل `input.*` است، عوض کنید)
- Output file names template: `*.out` (پیش‌فرض `output.*`)
- Public: بدون تیک؛ Overwrite: بدون تیک
- انتظار: **69** تست در لیست.

## ۵. Score Parameters
حالا Score Type = `GroupMin` و در **Score Parameters** کل محتوای `score_type_parameters.json` را paste کنید → **Update**.

| index | زیرمسئله | امتیاز | تعداد تست |
|---|---|---|---|
| 0 | samples | 0 | 2 |
| 1 | small | 9 | 15 |
| 2 | onlyUR | 11 | 15 |
| 3 | tworows | 17 | 14 |
| 4 | minUR | 23 | 13 |
| 5 | full | 40 | 69 |

جمع امتیاز: 100

## ۶. افزودن به آزمون
صفحه‌ی آزمون → Tasks → افزودن `conveyor`. زبان‌های مجاز آزمون فقط C++ (grader فقط C++ دارد).

---
بررسی‌های خودکار این بسته: checker = ELF static x86-64 (g++ -x c++ -std=gnu++14 -O2 -static)؛
grader + `solution/model.cpp` با دستور C++14 خود CMS کامپایل و روی 2 نمونه‌ی public با checker قبول شد؛
هر regex دقیقاً تست‌های همان زیرمسئله را می‌گیرد؛ هر zip کمتر از ۷۰MB و تخت است؛ پیوست بدون داده‌ی مخفی.
